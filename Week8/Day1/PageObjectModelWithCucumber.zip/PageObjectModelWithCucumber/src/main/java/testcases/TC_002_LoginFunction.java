package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002_LoginFunction extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="Login";

	}
	
	
	@Test(dataProvider = "fetchdata")
	public void loginFunction(String username,String password) {
		LoginPage lp=new LoginPage();  //abcd
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton();

	}

}
//    filename=CreateLead
//   @BeforeTest      @DataProvider    @BeforeMethod    @Test      @AfterMethod