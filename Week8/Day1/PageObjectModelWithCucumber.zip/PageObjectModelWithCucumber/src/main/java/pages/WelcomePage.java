package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass {
	

 
  @Then("It should navigate to the next page")
  public WelcomePage verifyLogin() {
	  System.out.println("Login Successful");
	  return this;
  }
  @But("It throws the error message")
  public WelcomePage verifyErrorMessage() {
	  System.out.println("Login not successful");
	  return this;
  }
  @When("Click on the Crmsfa link")
	public MyHomePage clickCrmsfaLink() {
	  getDriver().findElement(By.linkText("CRM/SFA")).click();
        return new MyHomePage();
	}

}
