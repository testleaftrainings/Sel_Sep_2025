package base;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests{
//public EdgeDriver driver;
private static final ThreadLocal<EdgeDriver> driver=new ThreadLocal<EdgeDriver>();
public ExtentReports extent;
public String testcaseName,testcaseDescription,testcaseAuthor,testcaseCategory;
public static ExtentTest test;

public void setDriver() {
	driver.set(new EdgeDriver());
}

public EdgeDriver getDriver() {
	EdgeDriver edgeDriver = driver.get();
	return edgeDriver;
}

public String filename;
@BeforeMethod
public void preConditions() {
	//driver=new EdgeDriver();
	setDriver();
	getDriver().get("http://leaftaps.com/opentaps/control/main");
	getDriver().manage().window().maximize();

}
@AfterMethod
public void postConditions() {
	getDriver().close();

}

@DataProvider(name="fetchdata")
public String[][] sendData() throws IOException {
	String[][] readData = ReadExcel.readData(filename);   //CreateLead
     return readData;
}

@BeforeSuite
public void startReport() {
	       //step1: Setup the path
			ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/leaftapsreports.html");

			//Step2: Create a Test
			extent=new ExtentReports();
			
			//Step3:Adding the test to the html page
			extent.attachReporter(reporter);

}


@BeforeClass
public void testcaseDetails() {
	test = extent.createTest(testcaseName,testcaseDescription);
    test.assignAuthor(testcaseAuthor);
    test.assignCategory(testcaseCategory);
}

public void reportStep(String status,String message) throws IOException {
	
	if(status.equalsIgnoreCase("Pass")) {
		test.pass(message,MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/image"+takeSnap()+".png").build());
	}

}

public int takeSnap() throws IOException {
	
	int random =(int) (Math.random()*99999999+99999999);
	File source = getDriver().getScreenshotAs(OutputType.FILE);
	
	File destination=new File("./Snaps/image"+random+".png");   //image1234, image 678
	
	FileUtils.copyFile(source, destination);
	
	return random;
}











@AfterSuite
public void stopReport() {
	
extent.flush();
}




}
