package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
//                                           CreateLead
	public static String[][] readData(String filename) throws IOException {
		//To open the workbook
		XSSFWorkbook wb=new XSSFWorkbook("./ExcelData/"+filename+".xlsx");
		
		//To locate the worksheet
		//XSSFSheet ws = wb.getSheet("Sheet1");
		 XSSFSheet ws = wb.getSheetAt(0);
		 
		 //To count the number of rows
		 //Including row1
		 int physicalNumberOfRows = ws.getPhysicalNumberOfRows();
		 System.out.println("The number of rows including row1: "+physicalNumberOfRows);
		 //excluding row1
		 int rowCount = ws.getLastRowNum();
		 System.out.println("The row count is: "+rowCount);
		 
		 //To count the number of columns
		 
		 int columnCount = ws.getRow(0).getLastCellNum();
		 System.out.println("The column count is "+columnCount);
		 
		 //To retrieve a single data
		 
		 String valueAtRow1Cell1 = ws.getRow(1).getCell(1).getStringCellValue();
		 System.out.println("The value is: "+valueAtRow1Cell1);
		 
		 String[][] data=new String[rowCount][columnCount];
		 
		 //To retrieve the entire data
		 //   1   2
		 for (int i = 1; i <= rowCount; i++) {
			
			 XSSFRow row = ws.getRow(i);
			 //XSSFRow row(1) = ws.getRow(1);
			//XSSFRow row(1) = ws.getRow(2);
			
			 //       0    1    2   
			 for (int j = 0; j < columnCount; j++) {
				String allData = row.getCell(j).getStringCellValue();
				data[i-1][j]=allData;
			//  data[0][0]=Qeagle;
			//  data[0][1]=Hari;
			//  data[0][2]=R;
				
			//  data[1][0]=TestLeaf;
			//  data[1][1]=Seenivasan;
			//  data[2][2]=S;	
			//  String allData = row(1).getCell(0).getStringCellValue();	//Qeagle  data[0][0]
		    //  String allData = row(1).getCell(1).getStringCellValue();    //Hari    data[0][1]
			//  String allData = row(1).getCell(2).getStringCellValue();	//R       data[0][1]
			
			//  String allData = row(2).getCell(0).getStringCellValue();     //TestLeaf	
			//  String allData = row(2).getCell(1).getStringCellValue();     //Seenivasan
			//  String allData = row(2).getCell(2).getStringCellValue();      //S
				System.out.println("The entire data in excel: "+allData);
			}
			 
		}
		 wb.close();
		 return data;
	}

}
