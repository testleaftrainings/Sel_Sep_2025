package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002_LoginFunction extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="Login";
		
		testcaseName="Login";
		testcaseDescription="Login with valid credentials";
		testcaseAuthor="Saranya";
		testcaseCategory="Smoke";

	}
	
	
	@Test(dataProvider = "fetchdata")
	public void loginFunction(String username,String password) throws IOException {
		LoginPage lp=new LoginPage();  //abcd
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton();

	}

}
//    filename=CreateLead
//   @BeforeTest      @DataProvider    @BeforeMethod    @Test      @AfterMethod