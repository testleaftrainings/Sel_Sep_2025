package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyHomePage extends BaseClass{

@When("Click on the Leads link")
	public MyLeadsPage clickLeadsLink() {
	getDriver().findElement(By.linkText("Leads")).click();
        return new MyLeadsPage();
	}

}
